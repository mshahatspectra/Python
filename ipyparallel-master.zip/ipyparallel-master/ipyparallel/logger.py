if __name__ == '__main__':
    from ipyparallel.apps import iploggerapp as app
    app.launch_new_instance()
