version_info = (6, 2, 0, 'dev')
__version__ = '.'.join(map(str, version_info))
